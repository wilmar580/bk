const mongoose = require('mongoose') //libreria u orm para conectarnos con mongodb y hacer consultas,

//definición del esquema
const jugadorSchema = new mongoose.Schema
    ({
        name: { type: String, lowercase: true },
        apellido: String,
        posicion: String,
        edad: String,
        equipo:String,
        


    })

module.exports = mongoose.model('jugadores', jugadorSchema)