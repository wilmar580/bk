const mongoose = require('mongoose') //libreria u orm para conectarnos con mongodb y hacer consultas,

//definición del esquema
const equipo1Schema = new mongoose.Schema
    ({
        nombre: { type: String, lowercase: true },
        tecnico: String,
        color: String,
      
        


    })

module.exports = mongoose.model('equipo1', equipo1Schema)