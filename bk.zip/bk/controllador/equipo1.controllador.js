const Equipo = require('../model/equipo1')
const jugador =require('../model/jugadores')

   const ctrlContact = {}
    // llamar al modelo
  // mail = require('../service/mail')
   //sendMQ = require('../service/send')
    //consumer = require('../io/consumer')
   
   // llega datos via post 
   ctrlContact.create = async(req, res) => { //funcion crear usuario
       //desestructuracion}
       const { nombre, tecnico, color, } = req.body
       console.log(req.body)
       const newContact = new Equipo({ //se definen los datos de contacto
           mombre: nombre,
           tecnico: tecnico,
            color: color,
           
           
       })
       await newContact.save() // guarda un usuario
           // mail.sendMailContact(req.body) // luego le envia el correo 
           // UNION DE RABBIT Y POSTMAN ENVIO DE INFORMACION  sendMQ.sendToNewQueue("contact", JSON.stringify(req.body)) // guarda toda la informacion desde postman
   
       res.json({ status: true })
   
   }
   
   ctrlContact.get = async(req, res) => { // va y contulte todos los registros del modelo contacts de line 14
       const contacts = await Equipo.find({}) // buscar todo sin condicion ({})
       res.json(contacts) // se crea ruta router.get('/', contactCtrl.get) en contact. route.js
   }
   
   
   ctrlContact.findById = async(req, res) => { // una sola busqueda // findById se agrega la ruta en contact router
       let contacts = await Equipo.find({ _id: req.body._id }) // busqueda id  por post
       if(contacts){                                          // si encontro un equipo
        let jugadores =await jugador.find({
               equipo: req.body._id
           })
           contacts['jugadores']= jugadores
       }
       res.json(contacts) // toda respuesta pasela a json
   }
   
   ctrlContact.findById = async(req, res) => { // busqueda id por get en bd
       console.log(req.params._id)
       let contact = await Equipo.find({ _id: req.params._id })
       let equipo = {
        nombre: '',
        color: '',
        tecnico: '',
        jugadores: []
        }
       if(contact){ 
           console.log("equipo encontrado", contact)                                         // si encontro un equipo
        let jugadores =await jugador.find({
               equipo: req.params._id
           })
           console.log("jugadores encontrado",jugadores)
           equipo.nombre = contact[0].nombre
           equipo.color = contact [0].color
           equipo.tecnico= contact [0].tecnico
           equipo['jugadores']=jugadores
           console.log("equipo al final",equipo)
       }
       res.json(equipo) // toda respuesta pasela a json
   }
   
   ctrlContact.remove = async(req, res) => { // eliminar 1 con deleteOne
       console.log(req.params._id);
       await Equipo.deleteOne({ _id: req.params._id })
       res.json({ status: true }) // toda respuesta pasela a json
   }
   
   ctrlContact.update = async(req, res) => {
       console.log(req.body)
       const { _id, name, apellido, posicion, edad } = req.body // se realiza busqueda por id y actualiza los campos
       let toUpdate = {
           _id: _id,
           nombre: nombre,
           tecnico: tecnico,
           color: color,
           
   
       }
       await Equipo.findOneAndUpdate({ _id: _id }, toUpdate) // busque uno y actualice la bd findOneAndUpdate
       res.json({ status: true }) // toda respuesta pasela a json
   }
   
   ctrlContact.search = async(req, res) => { // buscador con cualquier letra un solo campo
       const { name } = req.body // busqueda de un solo campo  pendiente email, subject, message
       const contact = await Equipo.find({ name: { $regex: "." + name + "." } })
       res.json(contact) // toda respuesta pasela a json
   }
   
   
   
   module.exports = ctrlContact