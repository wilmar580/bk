const express = require('express'),
    router =  express.Router(),
    equipo1tCtrl = require('../controllador/equipo1.controllador')

router.get('/', equipo1tCtrl.get)
router.post('/',equipo1tCtrl.create)
router.post('/findById',equipo1tCtrl.findById)
router.post('/search', equipo1tCtrl.search)
router.get('/search', equipo1tCtrl.search)
router.put('/', equipo1tCtrl.update)
router.get('/:_id',equipo1tCtrl.findById)
router.delete('/:_id', equipo1tCtrl.remove)

module.exports = router