const { Router } = require('express'),
    router = Router()

router.use('/jugadores', require('../router/jugadores.router'))
router.use('/equipo1', require('../router/equipo1.router'))

module.exports = router