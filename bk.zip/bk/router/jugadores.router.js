const express = require('express'),
    router =  express.Router(),
    jugadoresCtrl = require('../controllador/jugadores.controllador')

    router.get('/', jugadoresCtrl.get)
    router.post('/',jugadoresCtrl.create)
    router.post('/findById',jugadoresCtrl.findById)
    router.post('/search', jugadoresCtrl.search)
    router.get('/search', jugadoresCtrl.search)
    router.put('/', jugadoresCtrl.update)
    router.get('/:_id',jugadoresCtrl.findById)
    router.delete('/:_id', jugadoresCtrl.remove)
    



module.exports = router