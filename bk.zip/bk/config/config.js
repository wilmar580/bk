module.exports = {
    port: process.env.PORT || 3000, //escoja el puerto si no hay uno definido conectece al 3000
    //urlDb: process.env.MONGODB || 'mongodb://localhost:27017/web', // si hay puerto configurado en MONGODB ingrese si no ingrese al link
    urlDb: process.env.MONGODB || 'mongodb+srv://wilmar580:andrey580@cluster0.p9b61.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', //se enlaza base con mongo web
    user: 'correo', // se enlaza con bk mail.js auth: para manejar user y pwd
    pwd: "clave*" // se enlaza con bk mail.js auth: para manejar user y pwd
}