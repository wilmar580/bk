const express = require('express')
config = require('./config/config')
app = express()
bodyParser = require('body-parser')
cors = require('cors')
http = require('http').Server(app)
io = require("socket.io")(http, {
    cors: {
        origins: ['http://localhost:4200/']
    }
})
url = config.urlDb
db = require('./data/data')
consumer = require('./io/consumer')
consumer.start(io)
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(cors())
//app.use(methodOverride('_method'))
app.use("/api", require('../bk/router/'))

http.listen(config.port, () => {
    console.log(`Server is running in port ${config.port}`);
});